package storm.trident.operation;


public abstract class BaseFunction extends BaseOperation implements Function {
    
}
