package backtype.storm.topology.base;

import backtype.storm.transactional.TransactionAttempt;

public abstract class BaseTransactionalBolt extends BaseBatchBolt<TransactionAttempt> {
    
}
