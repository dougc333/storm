package backtype.storm.task;


public interface IMetricsContext {
    
}
